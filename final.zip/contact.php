<?php
   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      if(isset($_POST['honeypot']) && !empty($_POST['honeypot'])) {
         echo "Bot activity detected.";
         exit;
      } 
   } else {
        // page was processed normally 
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <style>
       form {
		border: 1px black solid;
       	  	padding: 10px;
       	  	width: 70%;
       	  	margin: 0 auto;
       	  	margin-bottom: 40px;
        }
        
        textarea {
        	width:100%;
        	height: 200px;
        }
        
        .container {
           text-align: left;
        }
       
        .button {
           border: 1px solid #145214;
           background-color: #145214;
           color: white;
           font-size: 15px;
           padding: 10px 20px;
           margin: 20px;
        }      
        
        .no-show {
               display: none;
        }        
    </style>
</head>
<body>
    <h1>Green Spirits High School</h1>
    
    <div class="header">
    	<a href="index.php">Home</a>
    	<a href='news.php'>News</a>
    	<a href='staff.php'>Staff</a>
    	<a href="contact.php">Contact</a>
    	<div class="dropdown">
    	   <a class="dropbutton">Admin</a>
    	   <div class="dropdown-content">
    	      <a href="login.php">Login</a>
    	      <a href="logout.php">Logout</a>
    	   </div>
       </div>	   
    </div>
    <br>
    <br>
    <h3>Thank you for choosing to contact us regarding school activities.<br>A member of our staff will follow up as soon as possible.</h3>
    
    <form id="contact" name="contact" method="post" action="contactHandler.php">
        <label for="name">Name:</label>
        <input type="text" name="name" required>
        <br><br>
        <label for="email" name="email">Email:</label>
        <input type="text" name="email" required>
        <br><br>
        <p>Student or Guardian:</label>
        <br>
        <input type="radio" id="student" name="role" required>
        <label for="student"name="studentParent">Student</label>
        <br>
        <input type="radio" id="parent" name="role" required>
        <label for="parent" name="studentParent">Guardian</label>
        <br><br>

	<p>Reason for contacting:</p>
	
	<textarea name="note" required></textarea>
	
	<input class="no-show" type="text" name="honeypot">

	<div class="container">
           <button name="button" class="button" id="button" value="Submit">Submit</button>
        </div>

    </form>
    
    <footer name="footer" class="footer">
    	<p> A School Project © <?php echo date('Y');?> </p>
    	<p>Created by Pamela Salas</p>
    </footer>
</body>
</html>