<?php
        session_start();
	require_once 'functions.php';
	require_once '../includes/db_connect.php';
	

	    if(isset($_POST['submit'])) { // if theyre in the process of logging in
        $user = $_POST['username'] ?? '';
        $pw = $_POST['password'] ?? '';
        
        if(log_in($user, $pw)) {
            header("Location: index.php?message=Welcome back, " . $username);
        } else {
            $error_message = "Invalid Credentials";
        }
    }
    
    $logged_in = isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] == true;    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            document.querySelectorAll(".delete-link").forEach(link => {
            	link.addEventListener("click", function(e) {
                	e.preventDefault();

                	if(confirm("Are you sure?")) {
                    	   window.location.href = this.href;
                	
                       }
                });
            });
               
        });
    </script>
    <style>
	h1 {
	   color: white;
	}    
    
    	.container {
    		text-align: center;
    		width: 70%;
    		margin: 0 auto;
    	}
	.button {
		background-color: #145214;
		color: white;
		padding: 10px 20px;
		text-align: center;
		display: block;
		margin: 50px auto;
		width: 150px;
		text-decoration: none;
	}
	
    	table {
    		border-collapse: collapse;
    		//display: flex;
    		margin: 20px auto;
    		background-color: white;
    		width: 85%;
    	}
    	
    	th {
    		padding: 10px;
    		font-size: 18px;
    	}
    	
    	td {
    		text-align: center;
    	}
    	
    	.rowHeight {
        	height: 50px;
    	}
    	
    	td a {
    		text-decoration: none;
    		color: #145214;
    	}
    	
 	.updated {
 	   text-align: right;
 	   font-size: 12px;
 	   padding-right: 110px;
 	}    	
    </style>
</head>
<body>
    <?php
        if(isset($_GET["message"])) {
            echo "<h3>" . htmlspecialchars($_GET["message"]) . "</h3>";
        }
    ?>

    <h1 class="logo">Green Spirits High School</h1>
    
    <div class="header">
    	<a href="index.php">Home</a>
    	<a href='news.php'>News</a>
    	<a href='staff.php'>Staff</a>
    	<a href="contact.php">Contact</a>
    	<div class="dropdown">
    	   <a class="dropbutton">Admin</a>
    	   <div class="dropdown-content">
    	      <a href="login.php">Login</a>
    	      <a href="logout.php">Logout</a>
    	   </div>
       </div>	   
    </div>
    
    <div class="container">
       <h3>Welcome to our Green Spirits High School events page. Here, staff can add events happening in the school year-round! We look forward to communicating about
       student events and other updates, and we'll be able to update students, parents, and staff through this website! Please feel reach to reach out with any
       questions or comments!</h3>
    </div>

    
    <p class="updated">
       <?php
          $file = 'index.php';
	  
	  if (file_exists($file)) {
             echo "Last updated: " . date("F d Y \a\\t g:i A", filemtime($file));
          }
         
       ?>
    </p>    

    <table border = "1">
        <tr>
            <th>Event Name</th>
            <th>Event Description</th>
            <th>Event Presenter</th>
            <th style="width: 100px;">Event Date</th>
            <th style="width: 80px;">Event Time</th>
            <?php 
               if ($logged_in): 
            ?>
               <th>Delete</th>
               <th>Update</th>
            <?php
               endif;
            ?>
        </tr>

        <?php
            $stmt = $pdo->query("Select * FROM wdv341_events");
            
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            	$dateFormat = date('m/d/Y', strtotime($row['event_date']));
            	$timeFormat = date("g:i A", strtotime($row['event_time']));
                echo "<tr class='rowHeight'>
                        <td>{$row['event_name']}</td>
                        <td>{$row['event_description']}</td>
                        <td>{$row['event_presenter']}</td>
                        <td>{$dateFormat}</td>
                        <td>{$timeFormat}</td>";

                if ($logged_in) {
                        echo "<td><a class='delete-link' href='deleteEvent.php?id={$row['id']}'>Delete</a></td>
               	        <td><a class='update-link' href='updateEvent.php?id={$row['id']}'>Update Event</a></td>";
                }
            	echo "</tr>";  
           }
        ?>

    </table>
    <?php
       if ($logged_in):
    ?>
             <a href="selectEvents.php" class="button">Add Event</a> 
    <?php 
       endif;
    ?>
    
    <footer name="footer" class="footer">
    	<p> A School Project © <?php echo date('Y');?> </p>
    	<p>Created by Pamela Salas</p>
    </footer>
    
    </body>
</html>