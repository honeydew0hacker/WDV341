<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Page</title>
    
    <link rel="stylesheet" type="text/css" href="style.css">

    <style>	
	img {
	  width: 180px;
	  height: 180px;
	  display: block;
	  margin: 0 auto;
	}
	
	table {
	   margin: 30px;
	   width: 95%;
	   border-collapse: separate;
	   border-spacing: 20px 20px;
	}
	
	.headers {
	   text-align: center;
	}
	
	h2{
	   text-align: center;
	}
	
	p {
	   text-align: center;
	   padding: 0px 55px 0px 55px;
	}
	
	td {
	   padding: 20px;
	   text-align: center;
	   justify-content: space-evenly;
	   border-radius: 10px;
	   box-shadow: 0 3px 5px #000000;
	}
	
	td strong {
	   display: block;
	   font-size: 15px;
	   margin-bottom: 5px;
	   color: #145214;
	}
    </style>
</head>
<body>
    <h1>Green Spirits High School</h1>
    
    <div class="header">
    	<a href="index.php">Home</a>
    	<a href='news.php'>News</a>
    	<a href='staff.php'>Staff</a>
    	<a href="contact.php">Contact</a>
    	<div class="dropdown">
    	   <a class="dropbutton">Admin</a>
    	   <div class="dropdown-content">
    	      <a href="login.php">Login</a>
    	      <a href="logout.php">Logout</a>   	      
    	   </div>
       </div>	   
    </div>
    
    <h2>Meet Our Dedicated Staff leaders!</h2>
    <p>At Green Spirits High School, our dedicated staff goes above and beyond the classroom to lead engaging student clubs. As a newer school, we are continually looking to expand the range of activities we offer to meet diverse student interests. Currently, our teachers facilitate spaces for students to build technical skills, explore artistic passions, and improve physical health through clubs like Robotics, Computer Science, Book Club, Photography, Tennis, and Running, developing strong team spirit through collaboration and shared interests. We look forward to launching new clubs soon!</p>
    
    <table>
    	<tr>
    	   <td class="staff">
    	      <h3>Mrs.Trist <br><strong>Book Club</strong></h3>
    	      <img src="teachers/teacher1.jpg">
    	      <p>Mrs.Trist has been teaching at Green Spirits High School since 2019. In 2020, she helped start a book club (although online at the time) for students 
    	      who were looking for a supportive, collaborative space to explore diverse literature and developing deeper discussion skills.</p>
    	   </td>
    	   
    	   <td class="staff">
    	      <h3>Mr.Low <br><strong>Tennis Club</strong></h3>
    	       <img src="teachers/teacher2.jpg">
    	       <p>Mr. Low has been a dedicated teacher for 20 years. He is currently the host and leader of the Tennis Club, where he focuseson building fundamental
    	       skills, promoting good sportsmanship, and fostering a love for the game among all students.</p>
    	   </td>
    
    	   <td class="staff">
    	      <h3>Mr.Alvarez <strong>Robotics</strong></h3>
    	      <img src="teachers/teacher3.jpg">
    	      </p>As the Intro to Computer Science teacher and host of the Robotics Club, Mr. Alvarez is dedicated to bridging the gap between theory and application. 
    	      He encourages students to use code and engineering principles to design, build, and program working robotic solutions, cultivating innovative thinking 
    	      and valuable technical skills.</p>
    	   </td>
    	</tr>
    	
    	<tr> 
    	   <td class="staff">
    	      <h3>Ms.Andal <strong>Photography Club</strong></h3>
    	      <img src="teachers/teacher4.jpg">
    	      <p> Ms. Andal hosts the Photography Club, which serves as a creative hub for visual arts. Students under her guidance explore not only still photography
    	      but also cinematography, short film production, and visual storytelling. She encourages members to expand their technical skills while developing a 
    	      strong, unique artistic voice across various media.</p>
    	   </td>

    	   <td class="staff">
    	      <h3>Mr.Smith & Mr.Ryan <strong>Football Club</strong></h3>
    	      <img src="teachers/teacher5.jpg">
    	      <p>Mr.Smith & Mr.Ryan co-lead the American Football Club, dedicating themselves to teaching the fundamentals of the game, emphasizing strategy, 
    	      teamwork, and physical conditioning. They welcome students of all experience levels who are ready to learn discipline, promote good sportsmanship, and 
    	      build leadership skills both on and off the field.</p>
    	   </td>
    	   
    	   <td class="staff">
    	      <h3>Ms.Bernard <strong>Girls Soccor</strong></h3>
    	      <img src="teachers/teacher6.jpg">
    	      <p>Ms.Bernard is the enthusiastic leader of the Girls Soccer team, which proudly launched as a brand-new program for the 2024-2025 school year. She is 
    	      committed to establishing a strong foundation for the team, emphasizing teamwork, skill development, and creating a supportive, positive environment for 
    	      all players. Ms. Bernard is looking forward to growing the program and enjoying many successful seasons ahead.</p>
    	   </td>
    	</tr>
    </table>
    

    <footer name="footer" class="footer">
    	<p> A School Project © <?php echo date('Y');?> </p>
    	<p>Created by Pamela Salas</p>
    </footer>
    
    </body>
</html>