<?php
   session_start();
   require('functions.php');
   require_login();
   require_once '../includes/db_connect.php';
   
   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
     if(isset($_POST['honeypot']) && !empty($_POST['honeypot'])) {
        echo "Bot activity detected.";
        exit;
     } 
   } else {
        // page was processed normally 
   }

   $id = $_GET['id'] ?? null;   

   if (!$id) {
      header("Location: index.php?message=Invalid Event ID");
      exit;
   }


   $stmt = $pdo->prepare("SELECT event_name,
   				 event_description,
   				 event_presenter,
   				 event_date,
   				 event_time
   			  FROM wdv341_events 
   			  WHERE id = :id");
   			  
   $stmt->execute([':id' => $id]);
   $event = $stmt->fetch(PDO::FETCH_ASSOC);

   if (!$event) {
      header("Location: index.php?message=Event not found");
      exit;
   }

   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $event_name = $_POST['event_name'] ?? '';
      $eventDescription = $_POST['eventDescription'] ?? '';
      $eventPresenter = $_POST['eventPresenter'] ?? '';
      $eventDate = $_POST['eventDate'] ?? '';
      $eventTime = $_POST['eventTime'] ?? '';

   try {
      $sql = "UPDATE wdv341_events 
      	      SET event_name = :event_name,
                  event_description = :event_description,
                  event_presenter = :event_presenter,
                  event_date = :event_date,
                  event_time = :event_time
                  WHERE id = :id";

      $stmt = $pdo->prepare($sql);
      $stmt->execute([
            ':event_name' => $event_name,
            ':event_description' => $eventDescription,
            ':event_presenter' => $eventPresenter,
            ':event_date' => $eventDate,
            ':event_time' => $eventTime,
            ':id' => $id
        ]);

        header("Location: index.php?message=Event successfully updated!");
        exit;
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Event</title>
    
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <style>
         form {
        	border: none;
        	padding: 10px;
        	width: 35%;
        	margin: 0 auto;
        	margin-bottom: 40px;
        }
        
        textarea {
           width: 500px;
           height: 200px;
        }
        
       h2 {
          text-align: center;
       }
       
        .container {
           text-align: center;
        }
       
        .button {
           border: 1px solid #145214;
           background-color: #145214;
           color: white;
           font-size: 15px;
           padding: 10px 20px;
           margin: 20px;
           text-decoration: none;
        }       
        
       .no-show {
          display: none;
       }
       
    </style>
</head>
<body>

   <h1>Green Spirits High School</h1>
   
   <div class="header">
      <a href="index.php">Home</a>
      <a href='news.php'>News</a>
      <a href='staff.php'>Staff</a>
      <a href="contact.php">Contact</a>
      <div class="dropdown">
         <a class="dropbutton">Admin</a>
    	    <div class="dropdown-content">
    	       <a href="login.php">Login</a>
    	       <a href="logout.php">Logout</a>
    	    </div>
      </div>	   
    </div>
  
   <h2>Update Event</h2>

   <?php 
     if (!empty($error_message)) 
        echo "<p>Error: " . htmlspecialchars($error_message) . "</p>"; 
   ?>

   <form action="" method="POST" class="updateForm">
      <label>Event Name:</label>
      <input type="text" name="event_name" value="<?php echo htmlspecialchars($event['event_name']); ?>" required>
      <br><br>

      <label>Event Description:</label><br>
      <textarea name="eventDescription" required><?php echo htmlspecialchars($event['event_description']); ?></textarea>
      <br><br>

      <label>Event Presenter:</label>
      <input type="text" name="eventPresenter" value="<?php echo htmlspecialchars($event['event_presenter']); ?>" required>
      <br><br>

      <label>Event Date:</label>
      <input type="date" name="eventDate" value="<?php echo $event['event_date']; ?>" required>
      <br><br>

      <label>Event Time:</label>
      <input type="time" name="eventTime" value="<?php echo $event['event_time']; ?>" required>
      <br><br>
      
      <input class="no-show" type="text" name="honeypot">

      <div class="container">
         <input type="submit" class="button" value="Update Event">
      </div>
   </form>

   <div class="back">
      <a href="index.php" class="button">Back</a>
   </div>
   
   <footer name="footer" class="footer">
      <p> A School Project © <?php echo date('Y');?> </p>
      <p>Created by Pamela Salas</p>
   </footer>
</body>
</html>