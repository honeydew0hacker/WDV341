<?php
        session_start();
        require('functions.php');
        require_login();
        
    	require_once '../includes/db_connect.php';
    	
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
           if(isset($_POST['honeypot']) && !empty($_POST['honeypot'])) {
           echo "Bot activity detected.";
           exit;
           } 
        } else {
        // page was processed normally 
       }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Events Page</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        
        #school {
        	font-size: 75px;
        	text-align: center;
        }
        
        img {
        	display: block;
        	margin: 0 auto;
        	width: 800px;
        	height: 400px;
        	border: 1px solid black;
        	margin-top: 30px;
 
        }
        
        h2 {
        	text-align: center;
        }
        
        form {
        	border: none;
        	padding: 10px;
        	width: 35%;
        	margin: 0 auto;
        	margin-bottom: 40px;
        }
        
        textarea {
           width: 500px;
           height: 200px;
        }
        
       .no-show {
          display: none;
       }        
       
        .container {
           text-align: center;
        }
       
        .button {
           border: 1px solid #145214;
           background-color: #145214;
           color: white;
           font-size: 15px;
           padding: 10px 20px;
           margin: 20px;
        }   
    </style>
</head>
<body>
    <h1>Green Spirits High School</h1>
    
    <div class="header">
    	<a href="index.php">Home</a>
    	<a href='news.php'>News</a>
    	<a href='staff.php'>Staff</a>
    	<a href="contact.php">Contact</a>
    	<div class="dropdown">
    	   <a class="dropbutton">Admin</a>
    	   <div class="dropdown-content">
    	      <a href="login.php">Login</a>
    	      <a href="logout.php">Logout</a>
    	      <a href="newAdmin.php">Add New Admin</a>
    	   </div>
       </div>	   
    </div>

    <h2>Add a New School Event</h2> 
    <form action="processAddEvent.php" method="post"> 
        <label>Event Name:</label> 
        <input type="text" name="event_name" required><br><br> 

        <label>Event Description:</label> <br>
        <textarea name="eventDescription"></textarea><br>

        <label>Event Presenter:</label>
        <input type="text" name="eventPresenter" required><br><br>

        <label>Event Date:</label>
        <input type="date" name="eventDate" required><br><br>

        <label>Event Time:</label>
        <input type="time" name="eventTime" required><br><br> 
        
        <input class="no-show" type="text" name="honeypot">
	
	<div class="container">
           <input type="submit" class="button" value="Add Event" id="submit"> 
        </div>
    </form> 
   
    
    <footer name="footer" class="footer">
       <p> A School Project © <?php echo date('Y');?> </p>
       <p>Created by Pamela Salas</p>
    </footer>    
    
</body>
</html>