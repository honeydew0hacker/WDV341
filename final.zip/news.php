<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Page</title>
    
    <link rel="stylesheet" type="text/css" href="style.css">

    <style>
    	h2 {
    	   text-align: center;
    	}
    	
    	.intro {
    	   text-align: center;
    	   padding: 0px 55px 0px 55px;
    	}
	
	img {
	   width: 350px;
	   height: 200px;
	   display: block;
	   margin: auto;
	   padding-bottom: 10px;
	}
	
	table {
	   border-collapse: collapse;
	   width: 90%;
	   margin: 0 auto;
	   padding-bottom: 20px;
	}
	
	tr {
	   border-bottom: 5px dotted #145214;
	}
	
	.noBorder {
	   border-bottom: none;
 	}
 	
 	.updated {
 	   text-align: right;
 	   font-size: 12px;
 	   padding-right: 75px;
 	}  
	
    </style>
</head>
<body>
    <h1>Green Spirits High School</h1>
    <div class="header">
    	<a href="index.php">Home</a>
    	<a href='news.php'>News</a>
    	<a href='staff.php'>Staff</a>
    	<a href="contact.php">Contact</a>
    	<div class="dropdown">
    	   <a class="dropbutton">Admin</a>
    	   <div class="dropdown-content">
    	      <a href="login.php">Login</a>
    	      <a href="logout.php">Logout</a>
    	   </div>
       </div>	   
    </div>
    
    <h2>Club News & Updates</h2>
    <p class="intro">Welcome to the Green Spirits High School Club News page, your source for all announcements, highlights, and updates from our student
    organizations. Here you'll be able to find important information regarding our clubs and school news. Whether you're looking for the latest game results, new and
    upcoming clubs, or just want to see the awesome things our students are accomplishing, you'll find it right here! Don't forget to check back regularly so you
    don't miss a beat!</p>
    <br><br>
    <p class="updated">
       <?php
          $file = 'news.php';
	  
	  if (file_exists($file)) {
             echo "Last updated: " . date("F d Y \a\\t g:i A", filemtime($file));
          }
         
       ?>
    </p>
    
    <table>
       <tr class="headers">
          <th><th>
          <th><th>
       </tr>
       <tr>
          <td><h2>The football team grabs thrilling victory in regional opener!<img src="news/football.jpg"></h2></td>
          <td>The Green Spirits American Football team opened their regional season with an electrifying win over the Westside Cougars last Friday night. In a game
          that came down to the wire, the Spirits secured a 21-17 victory thanks to a powerful fourth-quarter drive. The defense, led by Coach Smith, was a dominant
          force, shutting down the Cougars' rushing attack in the second half. The game-winning sequence came with just two minutes left, when Quarterback Alex
          Johnson connected with receiver Maya Chen for a 40-yard completion, setting up a short rushing touchdown by running back Marcus Lee.<br>   
          <ul>
             <li><strong>Coaches' Corner:</strong> "This was a true team win," said Coach Ryan. "The grit and discipline they showed in the final minutes - that's what we preach in practice. We are building a program of <em>resilience</em></li>
             <li><strong>Next Game:</strong> The Spirits are home this Friday against the Northwood Ravens. Kickoff is at 7:00 PM - come support your team!</li>
          </ul></td>
       </tr>   
       
       <tr>
          <td><h2>Robotics Club: Heading to States!</h2> <img src="news/robotics.jpg"></td>
          <td>The Robotics Club is celebrating a phenomenal performance at the recent Tech Challenge Qualifier! Our team's custom-built robot, named "The Green
          Engineer," demonstrated brilliant efficiency and programming, earning them a top-four finish and a coveted spot in the upcoming State Championship.
          The students' success is a testament to the club's focus on teamwork and problem-solving, with members dedicating countless hours to design, fabrication 
          , and coding. They are now spending their after-school time optimizing "The Green Engineer's" autonomous routines and strengthening its mechanical structure
          for the next level of competition.<br>
          <ul>
             <li><strong>Beyond the Bot:</strong> Club President, Jessica Tran, highlighted the core lesson: "It's about leaning to fail 16 times and then getting
             to see it work flawlessly on the 17th. That is the true joy of engineering."</li>
             <li><strong>Support STEM:</strong> The club will be fundraising the next few weeks fr travel costs to the State Championship. See Mr. Lewis in the
             library if you'd like to donate and support our talented engineers!</li>
          </ul></td>
       </tr>
       
       <tr class="noBorder">
          <td><h2>New Club Alert!</h2><img src="news/news.jpg"></td>
          <td>Get ready to hit the track! The Student Council has just approved the addition of the Green Spirits Running Club, set to begin meeting next spring!
          This exciting new club will be led by Mr.Chen and Ms.Davis, two dedicated runners who are eager to share their passion for fitness. The club aims to create
          a supportive environment for students of all abilities, whether you're a complete beginner looking to run your first mile or an experienced athlete aiming
          for a new personal best. The focus will be on building endurance, learning proper technique, and developing habits for lifelong health.
          <ul>
             <li><strong>How to Join:</strong> Sign-up sheets are available now outside the main gym doors.</li>
             <li><strong>First Meeting:</strong> January 10th, after school. Meet at the gym at 3:15 PM for orientation!</li>
          </ul>
          </td>
       </tr>
    </table>

    <footer name="footer" class="footer">
    	<p> A School Project © <?php echo date('Y');?> </p>
    	<p>Created by Pamela Salas</p>
    </footer>
    
    </body>
</html>